# nixos-config-files
These are my NixOS configuration files, including configuration.nix
and hardware-configuration.nix. 

You will still need to:
1) Configure KDE
2) Add .bashrc
3) change wallpaper and launcher icon
